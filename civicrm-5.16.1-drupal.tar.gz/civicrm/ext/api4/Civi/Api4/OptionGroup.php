<?php

namespace Civi\Api4;

/**
 * OptionGroup entity.
 *
 * @package Civi\Api4
 */
class OptionGroup extends Generic\DAOEntity {

}
