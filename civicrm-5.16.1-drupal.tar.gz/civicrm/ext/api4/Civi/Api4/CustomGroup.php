<?php

namespace Civi\Api4;

/**
 * CustomGroup entity.
 *
 * @package Civi\Api4
 */
class CustomGroup extends Generic\DAOEntity {

}
