<?php

namespace Civi\Api4;

/**
 * EntityTag - links tags to contacts, activities, etc.
 *
 * @package Civi\Api4
 */
class EntityTag extends Generic\DAOEntity {

}
