<?php

namespace Civi\Api4;

/**
 * Mapping entity.
 *
 * This is a collection of MappingFields, for reuse in import, export, etc.
 *
 * @package Civi\Api4
 */
class Mapping extends Generic\DAOEntity {

}
