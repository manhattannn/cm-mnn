<?php
namespace Civi\Api4;

/**
 * GroupNesting entity.
 *
 * @package Civi\Api4
 */
class GroupNesting extends Generic\DAOEntity {

}
