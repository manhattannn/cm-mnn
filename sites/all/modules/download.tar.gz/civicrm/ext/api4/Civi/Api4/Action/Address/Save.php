<?php

namespace Civi\Api4\Action\Address;

/**
 * @inheritDoc
 */
class Save extends \Civi\Api4\Generic\DAOSaveAction {
  use AddressSaveTrait;

}
