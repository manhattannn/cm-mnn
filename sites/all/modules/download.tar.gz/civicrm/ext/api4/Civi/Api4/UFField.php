<?php

namespace Civi\Api4;

/**
 * UFField entity - aka profile fields.
 *
 * @package Civi\Api4
 */
class UFField extends Generic\DAOEntity {

}
