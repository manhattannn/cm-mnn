<?php

namespace Civi\Api4;

/**
 * ContributionPage entity.
 *
 * @package Civi\Api4
 */
class ContributionPage extends Generic\DAOEntity {

}
