<?php
namespace Civi\Api4;

/**
 * GroupOrganization entity.
 *
 * @package Civi\Api4
 */
class GroupOrganization extends Generic\DAOEntity {

}
