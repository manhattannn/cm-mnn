<?php

namespace Civi\Api4;

/**
 * MailSettings entity.
 *
 * @package Civi\Api4
 */
class MailSettings extends Generic\DAOEntity {

}
