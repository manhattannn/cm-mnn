<?php

namespace Civi\Api4;

/**
 * Participant entity, stores the participation record of a contact in an event.
 *
 * @package Civi\Api4
 */
class Participant extends Generic\DAOEntity {

}
