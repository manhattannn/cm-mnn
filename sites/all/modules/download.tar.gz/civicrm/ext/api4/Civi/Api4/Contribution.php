<?php

namespace Civi\Api4;

/**
 * Contribution entity.
 *
 * @package Civi\Api4
 */
class Contribution extends Generic\DAOEntity {

}
