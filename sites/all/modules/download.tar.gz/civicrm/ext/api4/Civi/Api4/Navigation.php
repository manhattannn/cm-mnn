<?php

namespace Civi\Api4;

/**
 * Navigation entity.
 *
 * @package Civi\Api4
 */
class Navigation extends Generic\DAOEntity {

}
