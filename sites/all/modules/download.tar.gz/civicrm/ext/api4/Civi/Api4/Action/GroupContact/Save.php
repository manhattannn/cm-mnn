<?php

namespace Civi\Api4\Action\GroupContact;

/**
 * @inheritDoc
 */
class Save extends \Civi\Api4\Generic\DAOSaveAction {
  use GroupContactSaveTrait;

}
