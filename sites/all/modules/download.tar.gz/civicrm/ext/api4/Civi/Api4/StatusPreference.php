<?php

namespace Civi\Api4;

/**
 * For setting "hush" preferences for system check alerts.
 *
 * @package Civi\Api4
 */
class StatusPreference extends Generic\DAOEntity {

}
