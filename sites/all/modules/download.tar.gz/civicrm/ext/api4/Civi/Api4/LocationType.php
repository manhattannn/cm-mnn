<?php

namespace Civi\Api4;

/**
 * LocationType entity.
 *
 * @package Civi\Api4
 */
class LocationType extends Generic\DAOEntity {

}
