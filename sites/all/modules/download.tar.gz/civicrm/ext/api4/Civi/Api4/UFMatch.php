<?php

namespace Civi\Api4;

/**
 * UFMatch entity - links civicrm contacts with users created externally
 *
 * @package Civi\Api4
 */
class UFMatch extends Generic\DAOEntity {

}
