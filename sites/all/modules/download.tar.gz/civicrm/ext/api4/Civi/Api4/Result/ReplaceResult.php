<?php
namespace Civi\Api4\Result;

class ReplaceResult extends \Civi\Api4\Generic\Result {
  /**
   * @var array
   */
  public $deleted = [];

}
