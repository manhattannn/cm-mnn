<?php

namespace Civi\Api4;

/**
 * MappingField entity.
 *
 * This represents one field in a Mapping collection.
 *
 * @package Civi\Api4
 */
class MappingField extends Generic\DAOEntity {

}
