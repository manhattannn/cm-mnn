<?php

namespace Civi\Api4\Action\Address;

/**
 * @inheritDoc
 */
class Update extends \Civi\Api4\Generic\DAOUpdateAction {
  use AddressSaveTrait;

}
