<?php
// This file declares a CSS theme for CiviCRM.

return array (
  'name' => 'shoreditch',
  'title' => 'Shoreditch',
  'prefix' => NULL,
  'url_callback' => '\Civi\Core\Themes\Resolvers::simple',
  'search_order' => 
  array (
    0 => 'shoreditch',
    1 => '_fallback_',
  ),
  'excludes' => 
  array (
  ),
);
