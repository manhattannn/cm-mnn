// https://civicrm.org/licensing
(function($) {
  $.fn.button.noConflict();
})(jQuery);
