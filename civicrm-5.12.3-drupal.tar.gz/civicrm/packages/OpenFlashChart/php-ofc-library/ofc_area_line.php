<?php

class area_line extends area_base
{
	function __construct()
	{
		$this->type      = "area_line";
		parent::__construct();
	}
}
