<?php

namespace Civi\Api4;

/**
 * MockArrayEntity entity.
 *
 * @method Generic\BasicGetAction get()
 *
 * @package Civi\Api4
 */
class MockArrayEntity extends Generic\AbstractEntity {

}
