<?php

namespace Civi\Api4;

/**
 * Relationship entity.
 *
 * @package Civi\Api4
 */
class Relationship extends Generic\DAOEntity {

}
