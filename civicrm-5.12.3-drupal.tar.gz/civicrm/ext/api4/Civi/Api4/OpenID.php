<?php

namespace Civi\Api4;

/**
 * OpenID entity.
 *
 * @package Civi\Api4
 */
class OpenID extends Generic\DAOEntity {

}
