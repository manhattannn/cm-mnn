<?php

namespace Civi\Api4;

/**
 * UFGroup entity - AKA profiles.
 *
 * @package Civi\Api4
 */
class UFGroup extends Generic\DAOEntity {

}
