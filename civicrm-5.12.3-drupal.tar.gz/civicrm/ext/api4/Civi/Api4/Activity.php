<?php

namespace Civi\Api4;

/**
 * Activity entity.
 *
 * An activity is a record of some type of interaction with one or more contacts.
 *
 * @package Civi\Api4
 */
class Activity extends Generic\DAOEntity {

}
