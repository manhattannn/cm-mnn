# Events terms & conditions configuration

- Navigate to Manage Events pages and select your event
![GDPR Manage Event screenshot](./images/manageevents.png)
- Go to the Configuration settings for your event
![GDPR Event Config screenshot](./images/configevents.png)
- Under the event configuration, there is now a Terms & conditions tab
![GDPR Event t&C screenshot](./images/eventt&c.png)
- Complete the settings for where you want the t&c's checkbox located and complete the title you wouldlike to appear with a description if any
- Under the Event Links button, navigate to hte Online Registration page to view the settings
![GDPR Event live link](./images/eventlivelink.png)
- The online live contribution page now displays the event terms & conditions
![GDPR Event Page screenshot](./images/eventslivepage.png)
